SKIPUNZIP=0
ui_print "ModFGO OPPO 2.129.0 compatibility test"
PKG="com.bilibili.fgo.nearme.gamecenter"
PKG_APK=$(pm path "$PKG" | sed -n 's/^package://p' | head -n 1)
[ -n "$PKG_APK" ] || abort "OPPO FGO package not installed"
GAME_LIB="${PKG_APK%/*}/lib/arm64/libil2cpp.so"
[ -f "$GAME_LIB" ] || abort "arm64 libil2cpp.so missing"
GAME_HASH=$(sha256sum "$GAME_LIB" | awk '{print $1}')
[ "$GAME_HASH" = "ce605921ad42c6a2b0dc8dc8743387442bff22204d05d520ea2a6955ad7304e6" ] || abort "Unsupported game library; patch not installed"
set_perm_recursive "$MODPATH" 0 0 0755 0644
ui_print "Game library verified; reboot required."
